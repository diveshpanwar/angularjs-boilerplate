angular.module("controllers").controller('signupController', ['$scope', function($scope) {
    $scope.heading = 'Signup';
}]);