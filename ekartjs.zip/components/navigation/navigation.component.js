angular.module("controllers").controller('navigationController', ['$scope', function($scope) {
    $scope.appTitle = 'AngularJS';
}]);