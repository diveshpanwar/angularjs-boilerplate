angular.module("controllers").controller('errorController', ['$scope', function($scope) {
    $scope.heading = 'Error';
}]);