angular.module('controllers').controller('dashboardController', [
  '$scope',
  function($scope) {
    $scope.pageTitle = 'Dashboard';
  }
]);
