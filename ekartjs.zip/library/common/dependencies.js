$.getScript('../../components/home/home.component.js', function() {
    console.log('Home Component Loaded.');
});
$.getScript('../../components/login/login.component.js', function() {
    console.log('Login Component Loaded.');
});
$.getScript('../../components/signup/signup.component.js', function() {
    console.log('Signup Component Loaded.');
});
$.getScript('../../components/error/error.component.js', function() {
    console.log('Error Component Loaded.');
});
$.getScript('../../components/navigation/navigation.component.js', function() {
    console.log('Navigation Component Loaded.');
});
$.getScript('../../components/single-product/single-product.component.js', function() {
    console.log('Signle Product Component Loaded.');
});